import_instruments_revised = function (url, token, drop_blank = TRUE, record_id = "record_id", 
          first_record_id = 1, envir = .GlobalEnv) 
{
  cli::cli_inform("Reading metadata about your project.... ")
  ds_instrument <- suppressWarnings(suppressMessages(REDCapR::redcap_metadata_read(redcap_uri = url, 
                                                                                   token = token)$data))
  form_name <- NULL
  instrument_name <- unique(pull(ds_instrument, form_name))
  cli::cli_inform("Reading variable labels for your variables.... ")
  raw_labels <- suppressWarnings(suppressMessages(REDCapR::redcap_read(redcap_uri = url, 
                                                                       token = token, raw_or_label_headers = "label", records = first_record_id)$data))
  if (dim(raw_labels)[1] == 0) {
    stop("\n    The first 'record_id' or custom id in df must be 1;\n    use option 'first_record_id=' to set the first id in df.", 
         call. = FALSE)
  }
  just_labels <- raw_labels
  just_labels_names <- stringr::str_replace(stringr::str_replace(names(just_labels), 
                                                                 "(\\(.*)\\(", "\\1"), "\\)(.*\\))", "\\1")
  cli::cli_inform(c("Reading your data.... ", i = "This may take a while if your dataset is large."))
  raw_redcapr <- suppressWarnings(suppressMessages(REDCapR::redcap_read_oneshot(redcap_uri = url, 
                                                                                token = token, raw_or_label = "label")$data))
  just_data <- raw_redcapr
  just_data[] <- mapply(nm = names(just_data), lab = memisc::relabel(just_labels_names), 
                        FUN = function(nm, lab) {
                          labelVector::set_label(just_data[[nm]], lab)
                        }, SIMPLIFY = FALSE)
  redcap <- just_data
  i <- which(names(redcap) %in% paste0(instrument_name, "_complete"))
  big_i <- c(0, i)
  n_instr_int <- length(big_i) - 1
  is_longitudinal <- any(names(redcap) == "redcap_event_name")
  is_repeated <- any(names(redcap) == "redcap_repeat_instrument")
  if (is_longitudinal && is_repeated) {
    meta <- c(1:4)
  } else if (is_repeated) {
    meta <- c(1:3)
  } else if (is_longitudinal) {
    meta <- c(1:2)
  } else {
    meta <- 1
  }
  for (data_set in seq_len(n_instr_int)) {
    curr_instr_idx <- (big_i[data_set] + 1):big_i[data_set + 
                                                    1]
    drop_dot_one <- redcap[, unique(c(meta, curr_instr_idx))]
    if (drop_blank == TRUE) {
      processed_blank <- make_instrument_auto_revised(drop_dot_one, 
                                              record_id = record_id)
    }else {
      processed_blank <- drop_dot_one
    }
    rownames(processed_blank) <- NULL
    if (nrow(processed_blank > 0)) {
      assign(instrument_name[data_set], processed_blank, 
             envir = envir)
    }else {
      warning(paste("The", instrument_name[data_set], "instrument/form has 0 records and will not be imported. \n"), 
              call. = FALSE)
    }
  }
  invisible()
}
