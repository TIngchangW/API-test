make_instrument_auto_revised = function (df, drop_which_when = FALSE, record_id = "record_id") 
{
  if (names(df)[1] != record_id) {
    stop("\n         The first variable in df must be `record_id`;\n         use option 'record_id=' to set the name of your custom id.", 
         call. = FALSE)
  }
  df <- drop_label(df, record_id)
  is_longitudinal <- any(names(df) == "redcap_event_name")
  if (is_longitudinal) {
    df <- drop_label(df, "redcap_event_name")
  }
  is_repeated <- any(names(df) == "redcap_repeat_instrument")
  if (is_repeated) {
    df <- drop_label(df, "redcap_repeat_instrument")
    df <- drop_label(df, "redcap_repeat_instance")
  }
  if (is_longitudinal & is_repeated) {
    first_col <- 5
  }else if (is_repeated) {
    first_col <- 4
  }else if (is_longitudinal) {
    first_col <- 3
  }else {
    first_col <- 2
  }
  last_col <- length(names(df))
  instrument <- df[, c(first_col:last_col), drop = FALSE]
  allMissing = rep(FALSE, nrow(instrument))
  for (i in 1:nrow(instrument)) {
    x = instrument[i,]
    allMissing[i] = all(is.na(x) | x == "")
 }

  if (drop_which_when == FALSE) {
    record_id_col <- which(colnames(df) == record_id)
    redcap_event_name_col <- which(colnames(df) == "redcap_event_name")
    record_repeat_inst_col <- which(colnames(df) == "redcap_repeat_instance")
    if (is_longitudinal) {
      if (is_repeated & !all(is.na(df[!allMissing, record_repeat_inst_col]))) {
        return(df[!allMissing, c(record_id_col, redcap_event_name_col, 
                                 record_repeat_inst_col, first_col:last_col)])
      }
      else {
        return(df[!allMissing, c(record_id_col, redcap_event_name_col, 
                                 first_col:last_col)])
      }
    }
    else {
      if (is_repeated & !all(is.na(df[!allMissing, record_repeat_inst_col]))) {
        return(df[!allMissing, c(record_id_col, record_repeat_inst_col, 
                                 first_col:last_col)])
      }
      else {
        return(df[!allMissing, c(record_id_col, first_col:last_col)])
      }
    }
  }else {
    return(df[!allMissing, c(first_col:last_col)])
  }
}
