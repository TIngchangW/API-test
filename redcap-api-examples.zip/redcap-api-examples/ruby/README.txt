To run these examples you will need the Ruby Curl gem:

gem install curb

NOTE: It's actually called 'curb', not 'curl'.


You also need the Ruby json gem:

gem install json
